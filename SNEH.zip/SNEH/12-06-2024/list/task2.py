# Create a list of names and then write code to sort the list alphabetically in descending order.

mylist=["world","LearnPython.com", "pineapple", "bicycle"]
mylist.sort(reverse=True)
print(mylist)

# mylist=[4,5,8,7,6]
# mylist.sort()
# print(mylist)