# Given three tuples, concatenate them into a single tuple while maintaining their original order

test_tup1 = (3, 4)
test_tup2 = (5, 6)
test_tup3 = (7, 8)

test_tup3 = test_tup1 + test_tup2 + test_tup3
print(test_tup3)
