city=input("city:")
age=input("age:")
name=input("name:")

tup=(city,name,age)
print(tup)