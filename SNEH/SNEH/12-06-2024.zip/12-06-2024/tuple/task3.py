# Create a tuple of your favorite movies, and then write code to print the first two movies and the last two movies in the tuple.

movies = ("The Godfather", "The Shawshank Redemption", "Spirited Away", "Inception")


print(f"First two movies: {movies[0]},{movies[1]}")

print(f"Last two movies: {movies[-2]},{movies[-1]}")