string = input("enter a string:-")

def string_func(string):
    
    for i in string:
        
        frequency=string.count(i)
        
        print(str(i) + str(frequency), end="")
        

string_func(string)