# matrix = [] 
  
# for i in range(5): 
      
#     # Append an empty sublist inside the list 
#     matrix.append([]) 
      
#     for j in range(3): 
#         matrix[i].append(j) 
          
# print(matrix)


# def flatten_list(matrix):
#     flat_list = []
#     for sublist in matrix:
#         for item in sublist:
#             flat_list.append(item)
#     return flat_list


# Write a function to flatten a nested list.

nested_list = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]


def flatten_list(nested_list):
    flat_list = []
    for sublist in nested_list:
        for item in sublist:
            flat_list.append(item)
    return flat_list


flat_list = flatten_list(nested_list)
print(flat_list)








